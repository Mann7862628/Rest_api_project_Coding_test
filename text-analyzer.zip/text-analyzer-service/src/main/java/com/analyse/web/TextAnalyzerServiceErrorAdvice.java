package com.analyse.web;

import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;
import static org.springframework.http.HttpStatus.NOT_FOUND;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.analyse.exception.BusinessException;
import com.analyse.exception.TextAnalyzerException;

@ControllerAdvice
public class TextAnalyzerServiceErrorAdvice {

	@ExceptionHandler({ RuntimeException.class })
	public ResponseEntity<String> handleRunTimeException(RuntimeException e) {
		return error(INTERNAL_SERVER_ERROR, e);
	}

	@ExceptionHandler({ TextAnalyzerException.class })
	public ResponseEntity<String> handleNotFoundException(TextAnalyzerException e) {
		return error(NOT_FOUND, e);
	}
	
	@ExceptionHandler({ BusinessException.class })
	public ResponseEntity<String> handleBusinessException(BusinessException e) {
		return error(NOT_FOUND, e);
	}
	

	@ExceptionHandler({ Exception.class })
	public ResponseEntity<String> handleException(TextAnalyzerException e) {
		return error(NOT_FOUND, e);
	}

	@ExceptionHandler({ Throwable.class })
	public ResponseEntity<String> handleException(Throwable e) {
		return error(NOT_FOUND, e);
	}

	private ResponseEntity<String> error(HttpStatus status, Throwable e) {
		return ResponseEntity.status(status).body(e.getMessage());
	}
}
