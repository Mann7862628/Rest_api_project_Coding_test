package com.analyse.service.impl;

import java.util.function.Predicate;

import org.springframework.stereotype.Service;

import com.analyse.constants.TextAnalyzerConstants;
import com.analyse.dto.TextAnalyzerDto;
import com.analyse.exception.BusinessException;
import com.analyse.exception.TextAnalyzerException;
import com.analyse.service.TextAnalyzerService;
import com.analyse.utils.ShapeDefinationUtil;
import com.analyse.utils.TextAnalyzer;

@Service
public class TextAnalyzerServiceImpl implements TextAnalyzerService {

	@Override
	public String defineShape(String inputShape) throws Exception {
		if (preValidation(inputShape)) {
			throw new BusinessException(TextAnalyzerConstants.DATA_NOT_VALID);
		}
		String definition = ShapeDefinationUtil.getShapeDefinition(inputShape);
		System.out.println("Output: " + definition);
		return definition;
	}

	@Override
	public String analyseText(TextAnalyzerDto textAnalyzerDto) throws Exception {
		if (preValidation(textAnalyzerDto)) {
			throw new BusinessException(TextAnalyzerConstants.DATA_NOT_VALID);
		}
		String output = TextAnalyzer.analyzeText(textAnalyzerDto.getText());
		if (output != null) {
			System.out.println("Output: " + output);
		}
		return output;
	}

	Boolean preValidation(String string) {
		Predicate<String> p1 = (s1) -> s1 == null || s1.isEmpty();
		return p1.test(string);
	}

	Boolean preValidation(TextAnalyzerDto textAnalyzerDto) {
		Predicate<TextAnalyzerDto> p1 = (p) -> (p == null)
				|| (p.getText() == null || p.getText().isEmpty());
		return p1.test(textAnalyzerDto);
	}

}