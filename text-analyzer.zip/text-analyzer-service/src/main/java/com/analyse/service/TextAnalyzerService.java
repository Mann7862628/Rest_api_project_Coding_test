package com.analyse.service;

import com.analyse.dto.TextAnalyzerDto;

public interface TextAnalyzerService {
	public String defineShape(String inputDateTime) throws Exception;
	public String analyseText(TextAnalyzerDto textAnalyzerDto) throws Exception;
}