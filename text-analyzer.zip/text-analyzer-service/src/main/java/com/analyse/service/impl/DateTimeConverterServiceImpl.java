package com.analyse.service.impl;

import java.time.LocalDateTime;
import java.util.function.BiPredicate;
import java.util.function.Predicate;

import org.springframework.stereotype.Service;

import com.analyse.constants.TextAnalyzerConstants;
import com.analyse.exception.TextAnalyzerException;
import com.analyse.service.DateTimeConverterService;
import com.analyse.utils.TextAnalyzerUtils;

@Service
public class DateTimeConverterServiceImpl implements DateTimeConverterService {

	@Override
	public String convertDateTimeToWord(String inputDateTime) throws Exception {
		if (preValidation(inputDateTime)) {
			new TextAnalyzerException(TextAnalyzerConstants.DATA_NOT_VALID);
		}
		LocalDateTime dateTime = TextAnalyzerUtils.parseDateTime(inputDateTime);
		String outputText = TextAnalyzerUtils.formatDateTime(dateTime);
		System.out.println("Input Date Time: " + inputDateTime);
		System.out.println("Output: " + outputText);
		return outputText;
	}

	@Override
	public String wordToDateTimeConverter(String word) throws Exception {
		if (preValidation(word)) {
			new TextAnalyzerException(TextAnalyzerConstants.DATA_NOT_VALID);
		}
		String output = null;
		try {
			output = TextAnalyzerUtils.convertTextToDateTime(word);
		} catch (Throwable e) {
			throw new Exception("Please enter the valid  date");
		}
		if (output != null) {
			System.out.println("Output: " + output);
		} else {
			throw new Exception("Please enter the valid  date");
		}
		return output;
	}

	@Override
	public long daysDifference(String firstDate, String secondDate) throws Exception {
		if (preValidation(firstDate, secondDate)) {
			new TextAnalyzerException(TextAnalyzerConstants.DATA_NOT_VALID);
		}
		long output = 0;
		try {
			output = TextAnalyzerUtils.daysDiff(firstDate, secondDate);
		} catch (Throwable e) {
			throw new Exception("Please enter the valid  date");
		}
		return output;
	}

	Boolean preValidation(String string) {
		Predicate<String> p1 = (s1) -> s1 == null || s1.isEmpty();
		return p1.test(string);
	}

	Boolean preValidation(String d1, String d2) {
		BiPredicate<String, String> p1 = (s1, s2) -> (s1 == null || s1.isEmpty()) || (s2 == null || s2.isEmpty());
		return p1.test(d1, d2);
	}
}