package com.analyse.service;


public interface DateTimeConverterService {
	public String convertDateTimeToWord(String inputDateTime) throws Exception;
	public String wordToDateTimeConverter(String word) throws Exception;
	public long daysDifference(String firstDate,String secondDate) throws Exception;
}